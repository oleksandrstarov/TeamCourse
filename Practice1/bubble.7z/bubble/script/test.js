//var assert = require('assert');
describe('Validate Import', function() {
    it('should return array when input contains only digits and spaces', function () {
      assert.throws(validateInput(''), 'invalid input');
      //assert.equal([],[]);
      assert.sameMembers(validateInput('3 2'), ['3', '2']);
      assert.equal(validateInput('5 f t'), null);
    });
});

describe('Create Elemets Row', function() {
    it('Should set div element with class "element" for each number', function () {
      assert.equal(document.getElementsByClassName('element').length, 0);
      //createElementsRow();
      assert.isAtLeast(3, 3, '3 is greater or equal to 3');
      assert(document.getElementsByClassName('element').length >= 1);
    });
});


describe('Sort', function() {
    it('should update variables and screen', function () {
      assert.equal(i, 0);
      //sort();
      i= 1;
      assert.isAtLeast(i, 1);
      //assert.equal([],[]);
    });
});

describe('Cancel', function() {
    it('should reset variables and screen', function () {
      onButtonCancelClick();
      assert.equal(i, 0);
      assert.equal(j, 0);
      assert.sameMembers(dataArray, []);
      assert.sameMembers(array, []);
      assert.equal(document.getElementById('inputDiv').style.display, 'initial');
      assert.equal(document.getElementById('sortingDiv').style.display, 'none');
      assert.equal(element.innerHTML, '');
    });
});
