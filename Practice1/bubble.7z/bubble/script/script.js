console.log('started');

var dataArray = [];
var array = [];

console.log(array);
var element = document.getElementById('result');
var firstPage = document.getElementById('inputDiv');

//element.innerHTML = array.join(' | ');
var buttonSort = document.getElementById('sort');
buttonSort.onclick = function(){
  onButtonSortClick();
}

function onButtonSortClick(){
  var inputString = document.getElementsByTagName('input')[0].value;
  dataArray = validateInput(inputString);
  if(dataArray) createElementsRow();
}

var buttonCancel = document.getElementById('back');
buttonCancel.onclick = function(){
  onButtonCancelClick();
}

function onButtonCancelClick(){
  dataArray = [];
  array = [];
  i = 0;
  j = 0;
  document.getElementById('inputDiv').style.display = 'initial';
  document.getElementById('sortingDiv').style.display = 'none';
  //remove all elements
  element.innerHTML = '';
}

var buttonNext = document.getElementById('next');
buttonNext.onclick = function(){
  sort();
}

function validateInput(inputString){
  try{
    console.log(inputString);
    if(inputString.trim().length == 0) {
      throw new Error('Please fill in numbers to be sorted');
      return null;
    }
    var dataArray = inputString.split(' ');
    for(var i=0; i<dataArray.length; i++){
      if(dataArray[i].trim().length == 0) {
        dataArray.splice(i,1);
        i--;
        continue;
      }
      console.log(dataArray[i]);
      if(isNaN(dataArray[i])){
        throw new Error(dataArray[i]+' is not a number!');
        return null;
      }
    }
  }catch(e){
    alert(e.message);
    return;
  }
  return dataArray;
}

function createElementsRow(){
  for(var i = 0; i<dataArray.length; i++){
    var dataCell = document.createElement('div');
    dataCell.setAttribute('class', 'element');
    dataCell.innerHTML = dataArray[i];
    element.appendChild(dataCell);
    array.push(dataCell);
  }
  //change page content
  document.getElementById('inputDiv').style.display = 'none';
  document.getElementById('sortingDiv').style.display = 'initial';
  sort();
}

console.log(array);

var i = 0;
var j = 0;

//adapted Bubble sort function - we are not able to use loops as we have to show animation for user.
function sort(){
    //remove focus and highlight
    var focusedElements = document.getElementsByClassName('element');
    for(var ii = 0; ii<focusedElements.length; ii++){
      if(focusedElements[ii].hasAttribute('focused')) focusedElements[ii].removeAttribute('focused');
      if(focusedElements[ii].hasAttribute('swaped')) focusedElements[ii].removeAttribute('swaped');
    }
    if(i == array.length - 1) {
      //exit
      //color first element
      array[j].setAttribute('sorted', '');
      return null;
    }
    array[j].setAttribute('focused', '');
    array[j+1].setAttribute('focused', '');

    var valueOne = 0 - array[j].innerHTML * -1;
    var valueTwo = 0 - array[j+1].innerHTML * -1;

    if(valueOne > valueTwo){
      var tempHolder = array[j].innerHTML;
      array[j].innerHTML = array[j+1].innerHTML;
      array[j+1].innerHTML = tempHolder;
      array[j].setAttribute('swaped', '');
      array[j+1].setAttribute('swaped', '');
    }
    j++;
    if(j == array.length - 1 - i) {
      array[j].setAttribute('sorted', '');
      j=0;
      i++;
    }
}
